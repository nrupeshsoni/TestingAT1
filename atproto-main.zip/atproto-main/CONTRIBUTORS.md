# Contributors

ATProto receives so many contributions that we could never list everyone who deserves it. However, in this document we want to give special thanks to contributors who solve particularly difficult tasks, send security disclosures, or in some way deserve recognition.

### The AT Protocol maintainers give their thanks to:

#### [rmcan](https://github.com/rmcan) Security disclosure, April 2023
