# AWS KMS

A Keypair-compatible wrapper for AWS KMS.