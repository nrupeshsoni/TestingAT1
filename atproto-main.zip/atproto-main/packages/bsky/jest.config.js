const base = require('../../jest.config.base.js')

module.exports = {
  ...base,
  displayName: 'Bsky App View',
}
