import { subsystemLogger } from '@atproto/common'

export const logger = subsystemLogger('bsky:image')

export default logger
