# ATP Common Library for Web

A library containing code which is shared between web-friendly ATP packages.
